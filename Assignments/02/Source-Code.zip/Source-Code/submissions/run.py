"""Offline inference entry point for the UPAR Challenge 2027 Track 1 baseline."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from PIL import Image
from torchvision import transforms
from torchvision.models import resnet50


BATCH_SIZE = 128
NUM_ATTRIBUTES = 40

# This is the official CSV-header order used to train the packaged checkpoint.
ATTRIBUTE_NAMES = (
    "Age-Young",
    "Age-Adult",
    "Age-Old",
    "Gender-Female",
    "Hair-Length-Short",
    "Hair-Length-Long",
    "Hair-Length-Bald",
    "UpperBody-Length-Short",
    "UpperBody-Color-Black",
    "UpperBody-Color-Blue",
    "UpperBody-Color-Brown",
    "UpperBody-Color-Green",
    "UpperBody-Color-Grey",
    "UpperBody-Color-Orange",
    "UpperBody-Color-Pink",
    "UpperBody-Color-Purple",
    "UpperBody-Color-Red",
    "UpperBody-Color-White",
    "UpperBody-Color-Yellow",
    "UpperBody-Color-Other",
    "LowerBody-Length-Short",
    "LowerBody-Color-Black",
    "LowerBody-Color-Blue",
    "LowerBody-Color-Brown",
    "LowerBody-Color-Green",
    "LowerBody-Color-Grey",
    "LowerBody-Color-Orange",
    "LowerBody-Color-Pink",
    "LowerBody-Color-Purple",
    "LowerBody-Color-Red",
    "LowerBody-Color-White",
    "LowerBody-Color-Yellow",
    "LowerBody-Color-Other",
    "LowerBody-Type-Trousers&Shorts",
    "LowerBody-Type-Skirt&Dress",
    "Accessory-Backpack",
    "Accessory-Bag",
    "Accessory-Glasses-Normal",
    "Accessory-Glasses-Sun",
    "Accessory-Hat",
)

_TRANSFORM = transforms.Compose(
    [
        transforms.Resize((256, 128)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=(0.485, 0.456, 0.406),
            std=(0.229, 0.224, 0.225),
        ),
    ]
)
_MODEL: torch.nn.Module | None = None
_DEVICE: torch.device | None = None


def _build_model() -> torch.nn.Module:
    """Create the trained architecture without requesting pretrained weights."""
    model = resnet50(weights=None)
    model.fc = torch.nn.Linear(model.fc.in_features, NUM_ATTRIBUTES)
    return model


def load_model() -> None:
    """Load the bundled model once and select CUDA when it is available."""
    global _MODEL, _DEVICE

    if _MODEL is not None:
        return

    _DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    weights_path = Path(__file__).resolve().parent / "model_state.pth"
    if not weights_path.is_file():
        raise FileNotFoundError(f"Packaged model weights were not found: {weights_path}")

    model = _build_model()
    state_dict = torch.load(weights_path, map_location="cpu", weights_only=True)
    model.load_state_dict(state_dict, strict=True)
    _MODEL = model.to(_DEVICE).eval()


def _validate_attribute_names(sample: dict[str, Any]) -> None:
    try:
        names = tuple(sample["attribute_names"])
    except KeyError as error:
        raise KeyError("Each sample must include 'attribute_names'.") from error

    if names != ATTRIBUTE_NAMES:
        raise ValueError(
            "Unexpected attribute_names order. The submission expects the official "
            "40-name Track 1 order used by the packaged checkpoint."
        )


def _load_image(sample: dict[str, Any]) -> torch.Tensor:
    _validate_attribute_names(sample)
    try:
        image_path = Path(sample["image_path"])
    except KeyError as error:
        raise KeyError("Each sample must include 'image_path'.") from error

    if not image_path.is_file():
        raise FileNotFoundError(f"Submission image does not exist: {image_path}")

    with Image.open(image_path) as image:
        return _TRANSFORM(image.convert("RGB"))


def predict_batch(samples: list[dict[str, Any]]) -> list[list[float]]:
    """Return one 40-probability row in official attribute order for each sample."""
    if not samples:
        return []
    load_model()
    assert _MODEL is not None and _DEVICE is not None

    images = [_load_image(sample) for sample in samples]
    output_rows: list[list[float]] = []

    with torch.no_grad():
        for start in range(0, len(images), BATCH_SIZE):
            batch = torch.stack(images[start : start + BATCH_SIZE]).to(
                _DEVICE, non_blocking=_DEVICE.type == "cuda"
            )
            if _DEVICE.type == "cuda":
                with torch.autocast(device_type="cuda", dtype=torch.float16):
                    logits = _MODEL(batch)
            else:
                logits = _MODEL(batch)

            probabilities = torch.sigmoid(logits).float().cpu()
            if probabilities.shape[1] != NUM_ATTRIBUTES:
                raise RuntimeError(
                    f"Model returned {probabilities.shape[1]} outputs; expected {NUM_ATTRIBUTES}."
                )
            if not torch.isfinite(probabilities).all() or not (
                (probabilities >= 0.0).all() and (probabilities <= 1.0).all()
            ):
                raise RuntimeError("Model produced non-finite or out-of-range probabilities.")
            output_rows.extend(probabilities.tolist())

    return output_rows


def predict_image(sample: dict[str, Any]) -> list[float]:
    """Compatibility wrapper for runners that invoke one sample at a time."""
    return predict_batch([sample])[0]
