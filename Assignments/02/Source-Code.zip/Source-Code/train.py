"""Experiment 1: train a simple ImageNet-pretrained ResNet-50 baseline."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
from typing import Any

import torch
from torch import nn

from src.dataset import PedestrianAttributeDataset
from src.experiment import (
    build_train_transform,
    build_validation_transform,
    create_loader,
    evaluate_model,
    set_seed,
)
from src.model import count_parameters, create_resnet50


REPO_ROOT = Path(__file__).resolve().parent
DATA_DIR = REPO_ROOT / "data"
TRAIN_CSV = DATA_DIR / "annotations" / "task1" / "train" / "gt.csv"
VAL_CSV = DATA_DIR / "annotations" / "task1" / "val" / "gt.csv"
METRIC_NAMES = (
    "mA",
    "Label_F1",
    "Instance_Acc",
    "Instance_Prec",
    "Instance_Rec",
    "Instance_F1",
    "Challenge_Avg",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/baseline_resnet50"))
    parser.add_argument(
        "--smoke-test",
        action="store_true",
        help="Run one limited epoch and checkpoint round-trip; not a real experiment.",
    )
    return parser.parse_args()


def train_one_epoch(
    model: nn.Module,
    loader: torch.utils.data.DataLoader[Any],
    loss_function: nn.Module,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    device: torch.device,
    use_amp: bool,
    max_batches: int | None = None,
) -> float:
    model.train()
    total_loss = 0.0
    total_samples = 0

    for batch_index, (images, targets) in enumerate(loader):
        if max_batches is not None and batch_index >= max_batches:
            break

        images = images.to(device, non_blocking=device.type == "cuda")
        targets = targets.to(device, non_blocking=device.type == "cuda")
        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast(device_type=device.type, enabled=use_amp):
            logits = model(images)
            if logits.ndim != 2 or logits.shape[1] != 40:
                raise RuntimeError(f"Expected model output [batch, 40], got {tuple(logits.shape)}.")
            loss = loss_function(logits, targets)

        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        batch_size = images.shape[0]
        total_loss += loss.item() * batch_size
        total_samples += batch_size

    if total_samples == 0:
        raise ValueError("Training loader produced no batches.")
    return total_loss / total_samples


def checkpoint_payload(
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    best_challenge_average: float,
    args: argparse.Namespace,
    attribute_names: tuple[str, ...],
) -> dict[str, Any]:
    return {
        "model_state": model.state_dict(),
        "optimizer_state": optimizer.state_dict(),
        "epoch": epoch,
        "best_challenge_avg": best_challenge_average,
        "training_arguments": vars(args),
        "attribute_names": list(attribute_names),
    }


def load_checkpoint(
    checkpoint_path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    attribute_names: tuple[str, ...],
) -> tuple[int, float]:
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    if tuple(checkpoint["attribute_names"]) != attribute_names:
        raise ValueError("Checkpoint attribute order does not match the official training CSV.")
    model.load_state_dict(checkpoint["model_state"])
    optimizer.load_state_dict(checkpoint["optimizer_state"])
    return int(checkpoint["epoch"]) + 1, float(checkpoint["best_challenge_avg"])


def append_log(log_path: Path, row: dict[str, float | int]) -> None:
    fieldnames = ["epoch", "train_loss", "val_loss", *METRIC_NAMES]
    write_header = not log_path.exists()
    with log_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def save_json(path: Path, contents: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(contents, handle, indent=2)


def run_smoke_checkpoint_round_trip(
    checkpoint_path: Path,
    device: torch.device,
    attribute_names: tuple[str, ...],
) -> None:
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    if tuple(checkpoint["attribute_names"]) != attribute_names:
        raise RuntimeError("Smoke-test checkpoint did not preserve attribute names.")
    reloaded_model = create_resnet50(pretrained=False).to(device)
    reloaded_model.load_state_dict(checkpoint["model_state"])
    if reloaded_model.fc.out_features != 40:
        raise RuntimeError("Smoke-test checkpoint model does not have 40 outputs.")
    print("Smoke-test checkpoint save/load: passed")


def main() -> None:
    args = parse_args()
    if args.epochs < 1 or args.batch_size < 1 or args.num_workers < 0:
        raise ValueError("epochs and batch-size must be positive; num-workers must be non-negative.")

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_amp = device.type == "cuda"
    output_dir = args.output_dir / "smoke_test" if args.smoke_test else args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("TORCH_HOME", str(REPO_ROOT / ".torch"))

    train_dataset = PedestrianAttributeDataset(TRAIN_CSV, DATA_DIR, transform=build_train_transform())
    val_dataset = PedestrianAttributeDataset(VAL_CSV, DATA_DIR, transform=build_validation_transform())
    if train_dataset.attribute_names != val_dataset.attribute_names:
        raise ValueError("Train and validation attribute orders differ.")

    train_loader = create_loader(
        train_dataset, args.batch_size, args.num_workers, True, device, args.seed
    )
    val_loader = create_loader(
        val_dataset, args.batch_size, args.num_workers, False, device, args.seed + 1
    )

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    model = create_resnet50(pretrained=True).to(device)
    parameter_count = count_parameters(model)
    loss_function = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    config = vars(args).copy()
    config.update(
        {
            "device": str(device),
            "mixed_precision": use_amp,
            "model": "torchvision.models.resnet50",
            "pretrained_weights": "ResNet50_Weights.IMAGENET1K_V2",
            "parameter_count": parameter_count,
            "attribute_names": list(train_dataset.attribute_names),
        }
    )
    config["resume"] = str(args.resume) if args.resume is not None else None
    config["output_dir"] = str(args.output_dir)
    save_json(output_dir / "config.json", config)

    print(f"Device: {device}; mixed_precision={use_amp}; parameters={parameter_count:,}")
    print(f"Output directory: {output_dir}")
    start_epoch = 1
    best_challenge_average = float("-inf")
    if args.resume is not None:
        start_epoch, best_challenge_average = load_checkpoint(
            args.resume, model, optimizer, device, train_dataset.attribute_names
        )
        print(f"Resumed from {args.resume} at epoch {start_epoch}.")

    epochs_to_run = 1 if args.smoke_test else args.epochs
    max_train_batches = 2 if args.smoke_test else None
    max_val_batches = 2 if args.smoke_test else None
    for epoch in range(start_epoch, start_epoch + epochs_to_run):
        train_loss = train_one_epoch(
            model,
            train_loader,
            loss_function,
            optimizer,
            scaler,
            device,
            use_amp,
            max_batches=max_train_batches,
        )
        val_loss, metrics = evaluate_model(
            model,
            val_loader,
            loss_function,
            device,
            use_amp,
            max_batches=max_val_batches,
        )
        row: dict[str, float | int] = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_loss": val_loss,
            **metrics,
        }
        append_log(output_dir / "training_log.csv", row)
        summary = " ".join(f"{name}={metrics[name]:.4f}" for name in METRIC_NAMES)
        print(f"Epoch {epoch}: train_loss={train_loss:.4f} val_loss={val_loss:.4f} {summary}")

        payload = checkpoint_payload(
            model,
            optimizer,
            epoch,
            max(best_challenge_average, metrics["Challenge_Avg"]),
            args,
            train_dataset.attribute_names,
        )
        last_checkpoint_path = output_dir / "last_checkpoint.pth"
        torch.save(payload, last_checkpoint_path)
        if metrics["Challenge_Avg"] > best_challenge_average:
            best_challenge_average = metrics["Challenge_Avg"]
            torch.save(payload, output_dir / "best_model.pth")
            save_json(output_dir / "best_metrics.json", {"epoch": epoch, **metrics})

    if args.smoke_test:
        run_smoke_checkpoint_round_trip(
            output_dir / "last_checkpoint.pth", device, train_dataset.attribute_names
        )
        print("Smoke test completed. Metrics above are not experiment results.")
    run_summary: dict[str, Any] = {
        "device": str(device),
        "mixed_precision": use_amp,
        "parameter_count": parameter_count,
    }
    if device.type == "cuda":
        peak_vram_mib = torch.cuda.max_memory_allocated(device) / (1024**2)
        run_summary["peak_cuda_memory_allocated_mib"] = peak_vram_mib
        print(f"Peak CUDA memory allocated: {peak_vram_mib:.1f} MiB")
    if args.smoke_test:
        save_json(output_dir / "smoke_summary.json", run_summary)


if __name__ == "__main__":
    main()
