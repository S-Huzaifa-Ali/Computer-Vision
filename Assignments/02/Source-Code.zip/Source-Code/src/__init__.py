"""Reusable foundations for UPAR Challenge 2027 Track 1."""

from .dataset import PedestrianAttributeDataset
from .metrics import compute_track1_metrics

__all__ = ["PedestrianAttributeDataset", "compute_track1_metrics"]
