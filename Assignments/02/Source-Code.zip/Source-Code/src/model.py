"""Minimal ResNet-50 model definition reusable by training and submission code."""

from __future__ import annotations

import torch.nn as nn
from torchvision.models import ResNet50_Weights, resnet50

from .dataset import NUM_ATTRIBUTES


def create_resnet50(
    num_attributes: int = NUM_ATTRIBUTES,
    pretrained: bool = True,
) -> nn.Module:
    """Create an ImageNet-pretrained ResNet-50 with a multi-label logit head."""
    if num_attributes != NUM_ATTRIBUTES:
        raise ValueError(f"UPAR Track 1 requires exactly {NUM_ATTRIBUTES} attributes.")

    weights = ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
    model = resnet50(weights=weights)
    model.fc = nn.Linear(model.fc.in_features, num_attributes)
    return model


def count_parameters(model: nn.Module) -> int:
    """Return the number of trainable and frozen parameters in a model."""
    return sum(parameter.numel() for parameter in model.parameters())
