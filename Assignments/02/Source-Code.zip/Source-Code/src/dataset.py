"""Dataset utilities for the official UPAR Track 1 annotation format."""

from __future__ import annotations

import csv
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Callable

import numpy as np
import torch
from PIL import Image, UnidentifiedImageError
from torch.utils.data import Dataset


NUM_ATTRIBUTES = 40
ImageTransform = Callable[[Image.Image], Any]


class PedestrianAttributeDataset(Dataset[tuple[Any, torch.Tensor]]):
    """Load an official Track 1 ``gt.csv`` and its images.

    Image paths in the official CSV are POSIX-style paths relative to the
    repository's ``data`` directory. Attribute order is preserved verbatim from
    the CSV header and is exposed through :attr:`attribute_names`.
    """

    def __init__(
        self,
        csv_path: str | Path,
        data_dir: str | Path | None = None,
        transform: ImageTransform | None = None,
    ) -> None:
        self.csv_path = Path(csv_path).expanduser().resolve()
        if not self.csv_path.is_file():
            raise FileNotFoundError(f"Annotation CSV does not exist: {self.csv_path}")

        default_data_dir = Path(__file__).resolve().parents[1] / "data"
        self.data_dir = Path(data_dir if data_dir is not None else default_data_dir).expanduser().resolve()
        if not self.data_dir.is_dir():
            raise FileNotFoundError(f"Data directory does not exist: {self.data_dir}")

        self.transform = transform
        self.attribute_names, self.relative_image_paths, labels = self._read_csv()
        self.labels = np.asarray(labels, dtype=np.float32)
        self.labels.setflags(write=False)

    def _read_csv(self) -> tuple[tuple[str, ...], tuple[str, ...], list[list[float]]]:
        image_paths: list[str] = []
        labels: list[list[float]] = []

        with self.csv_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            try:
                header = next(reader)
            except StopIteration as error:
                raise ValueError(f"Annotation CSV is empty: {self.csv_path}") from error

            header = [field.strip() for field in header]
            if len(header) != NUM_ATTRIBUTES + 1:
                raise ValueError(
                    f"Expected 1 image column plus {NUM_ATTRIBUTES} attribute columns in "
                    f"{self.csv_path}, found {len(header)} columns."
                )
            if header[0] != "# image":
                raise ValueError(
                    f"Expected first CSV header column to be '# image' in {self.csv_path}, "
                    f"found {header[0]!r}."
                )
            if len(set(header[1:])) != NUM_ATTRIBUTES:
                raise ValueError(f"Attribute names must be unique in {self.csv_path}.")

            for line_number, row in enumerate(reader, start=2):
                if not row:
                    raise ValueError(f"Empty row at {self.csv_path}:{line_number}.")
                if len(row) != NUM_ATTRIBUTES + 1:
                    raise ValueError(
                        f"Expected {NUM_ATTRIBUTES + 1} columns at {self.csv_path}:{line_number}, "
                        f"found {len(row)}."
                    )

                image_path = row[0].strip()
                if not image_path:
                    raise ValueError(f"Missing image path at {self.csv_path}:{line_number}.")

                try:
                    row_labels = [float(value.strip()) for value in row[1:]]
                except ValueError as error:
                    raise ValueError(
                        f"Non-numeric label at {self.csv_path}:{line_number}."
                    ) from error

                if not np.isin(row_labels, (0.0, 1.0)).all():
                    raise ValueError(
                        f"Labels must be binary 0/1 at {self.csv_path}:{line_number}; "
                        f"found {row[1:]}."
                    )

                image_paths.append(image_path)
                labels.append(row_labels)

        if not image_paths:
            raise ValueError(f"Annotation CSV has no data rows: {self.csv_path}")
        return tuple(header[1:]), tuple(image_paths), labels

    def __len__(self) -> int:
        return len(self.relative_image_paths)

    def image_path(self, index: int) -> Path:
        """Return the resolved absolute image path for a dataset index."""
        raw_path = self.relative_image_paths[index]
        relative_path = PurePosixPath(raw_path)
        if (
            relative_path.is_absolute()
            or PureWindowsPath(raw_path).is_absolute()
            or ".." in relative_path.parts
        ):
            raise ValueError(
                f"Image path must be relative to {self.data_dir}: "
                f"{raw_path!r}"
            )

        return self.data_dir.joinpath(*relative_path.parts)

    def __getitem__(self, index: int) -> tuple[Any, torch.Tensor]:
        image_path = self.image_path(index)
        if not image_path.is_file():
            raise FileNotFoundError(
                f"Image referenced by {self.csv_path} at dataset index {index} does not exist: "
                f"{image_path}"
            )

        try:
            with Image.open(image_path) as loaded_image:
                image = loaded_image.convert("RGB")
        except UnidentifiedImageError as error:
            raise RuntimeError(f"Unable to decode image: {image_path}") from error

        if self.transform is not None:
            image = self.transform(image)

        labels = torch.from_numpy(self.labels[index].copy())
        return image, labels
