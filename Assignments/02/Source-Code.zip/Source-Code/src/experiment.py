"""Small shared helpers for the Experiment 1 training and evaluation scripts."""

from __future__ import annotations

import random
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

from .dataset import NUM_ATTRIBUTES
from .metrics import compute_track1_metrics


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def build_train_transform() -> transforms.Compose:
    """Experiment 1 augmentation: resize, flip, mild colour jitter, normalize."""
    return transforms.Compose(
        [
            transforms.Resize((256, 128)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.02),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


def build_validation_transform() -> transforms.Compose:
    """Deterministic Experiment 1 validation preprocessing."""
    return transforms.Compose(
        [
            transforms.Resize((256, 128)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


def set_seed(seed: int) -> None:
    """Set practical CPU/CUDA seeds for repeatable local runs."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def seed_worker(worker_id: int) -> None:
    """Seed DataLoader workers; kept module-level for Windows multiprocessing."""
    worker_seed = torch.initial_seed() % 2**32
    random.seed(worker_seed)
    np.random.seed(worker_seed)


def create_loader(
    dataset: Dataset[Any],
    batch_size: int,
    num_workers: int,
    shuffle: bool,
    device: torch.device,
    seed: int,
) -> DataLoader[Any]:
    """Create a Windows-safe DataLoader with CUDA pinning when applicable."""
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=num_workers > 0,
        worker_init_fn=seed_worker,
        generator=generator,
    )


@torch.inference_mode()
def evaluate_model(
    model: nn.Module,
    loader: DataLoader[Any],
    loss_function: nn.Module,
    device: torch.device,
    use_amp: bool,
    max_batches: int | None = None,
) -> tuple[float, dict[str, float]]:
    """Evaluate logits with BCE loss and the official probability metrics."""
    model.eval()
    total_loss = 0.0
    total_samples = 0
    probability_batches: list[torch.Tensor] = []
    target_batches: list[torch.Tensor] = []

    for batch_index, (images, targets) in enumerate(loader):
        if max_batches is not None and batch_index >= max_batches:
            break

        images = images.to(device, non_blocking=device.type == "cuda")
        targets = targets.to(device, non_blocking=device.type == "cuda")
        with torch.amp.autocast(device_type=device.type, enabled=use_amp):
            logits = model(images)
            if logits.ndim != 2 or logits.shape[1] != NUM_ATTRIBUTES:
                raise RuntimeError(
                    f"Model must produce [batch, {NUM_ATTRIBUTES}] logits, got {tuple(logits.shape)}."
                )
            loss = loss_function(logits, targets)

        batch_size = images.shape[0]
        total_loss += loss.item() * batch_size
        total_samples += batch_size
        probability_batches.append(torch.sigmoid(logits).float().cpu())
        target_batches.append(targets.float().cpu())

    if total_samples == 0:
        raise ValueError("Evaluation loader produced no batches.")

    probabilities = torch.cat(probability_batches, dim=0)
    all_targets = torch.cat(target_batches, dim=0)
    return total_loss / total_samples, compute_track1_metrics(probabilities, all_targets)
