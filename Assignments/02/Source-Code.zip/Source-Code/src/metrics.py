"""Transparent NumPy implementation of the UPAR Track 1 validation metrics."""

from __future__ import annotations

from typing import Any

import numpy as np


def _as_numpy(values: Any, name: str) -> np.ndarray:
    """Convert NumPy arrays or PyTorch tensors to a CPU NumPy array."""
    if hasattr(values, "detach"):
        values = values.detach().cpu().numpy()
    array = np.asarray(values)
    if array.ndim != 2:
        raise ValueError(f"{name} must have shape [num_samples, num_attributes], got {array.shape}.")
    if array.shape[0] == 0 or array.shape[1] == 0:
        raise ValueError(f"{name} must contain at least one sample and one attribute.")
    return array


def _safe_ratio(numerator: np.ndarray | float, denominator: np.ndarray | float) -> np.ndarray:
    """Return zero wherever a precision/recall-style ratio is undefined."""
    numerator = np.asarray(numerator, dtype=np.float64)
    denominator = np.asarray(denominator, dtype=np.float64)
    result = np.zeros(np.broadcast_shapes(numerator.shape, denominator.shape), dtype=np.float64)
    np.divide(numerator, denominator, out=result, where=denominator != 0)
    return result


def compute_track1_metrics(
    probabilities: Any,
    targets: Any,
) -> dict[str, float]:
    """Compute the official UPAR Track 1 metrics.

    ``probabilities`` and ``targets`` have shape ``[samples, attributes]``.
    A prediction is positive only when ``probability > 0.5`` (strictly greater,
    matching the challenge rule).

    Per attribute, mA averages positive recall ``TP / (TP + FN)`` and negative
    recall ``TN / (TN + FP)``. Label_F1 is the harmonic mean of macro label
    precision and macro positive recall. Per instance, accuracy is
    ``|prediction ∩ target| / |prediction ∪ target|``; precision and recall are
    averaged over instances, then Instance_F1 is their harmonic mean.
    Challenge_Avg is the harmonic mean of mA and Instance_F1.

    Undefined ratios (zero denominator) evaluate to 0.0. This covers an
    attribute or instance with no relevant positives, no predicted positives,
    or an empty union, without raising or producing NaN.
    """
    probabilities = _as_numpy(probabilities, "probabilities").astype(np.float64, copy=False)
    targets = _as_numpy(targets, "targets").astype(np.float64, copy=False)

    if probabilities.shape != targets.shape:
        raise ValueError(
            f"probabilities and targets must have the same shape, got "
            f"{probabilities.shape} and {targets.shape}."
        )
    if not np.isfinite(probabilities).all() or np.any((probabilities < 0.0) | (probabilities > 1.0)):
        raise ValueError("probabilities must be finite values in [0, 1].")
    if not np.isin(targets, (0.0, 1.0)).all():
        raise ValueError("targets must contain only binary 0/1 values.")

    predictions = probabilities > 0.5
    targets_bool = targets.astype(bool)

    true_positive = np.logical_and(predictions, targets_bool).sum(axis=0)
    false_positive = np.logical_and(predictions, ~targets_bool).sum(axis=0)
    true_negative = np.logical_and(~predictions, ~targets_bool).sum(axis=0)
    false_negative = np.logical_and(~predictions, targets_bool).sum(axis=0)

    label_positive_recall = _safe_ratio(true_positive, true_positive + false_negative).mean()
    label_negative_recall = _safe_ratio(true_negative, true_negative + false_positive).mean()
    mean_accuracy = (label_positive_recall + label_negative_recall) / 2.0
    label_precision = _safe_ratio(true_positive, true_positive + false_positive).mean()
    label_f1 = _safe_ratio(
        2.0 * label_precision * label_positive_recall,
        label_precision + label_positive_recall,
    ).item()

    intersection = np.logical_and(predictions, targets_bool).sum(axis=1)
    union = np.logical_or(predictions, targets_bool).sum(axis=1)
    predicted_positive = predictions.sum(axis=1)
    target_positive = targets_bool.sum(axis=1)

    instance_accuracy = _safe_ratio(intersection, union).mean()
    instance_precision = _safe_ratio(intersection, predicted_positive).mean()
    instance_recall = _safe_ratio(intersection, target_positive).mean()
    instance_f1 = _safe_ratio(
        2.0 * instance_precision * instance_recall,
        instance_precision + instance_recall,
    ).item()
    challenge_average = _safe_ratio(
        2.0 * mean_accuracy * instance_f1,
        mean_accuracy + instance_f1,
    ).item()

    return {
        "mA": float(mean_accuracy),
        "Label_F1": float(label_f1),
        "Instance_Acc": float(instance_accuracy),
        "Instance_Prec": float(instance_precision),
        "Instance_Rec": float(instance_recall),
        "Instance_F1": float(instance_f1),
        "Challenge_Avg": float(challenge_average),
    }
