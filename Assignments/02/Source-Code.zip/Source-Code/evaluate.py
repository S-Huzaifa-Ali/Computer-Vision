"""Evaluate a saved Experiment 1 checkpoint on the official validation split."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import torch
from torch import nn

from src.dataset import PedestrianAttributeDataset
from src.experiment import build_validation_transform, create_loader, evaluate_model
from src.model import create_resnet50


REPO_ROOT = Path(__file__).resolve().parent
DATA_DIR = REPO_ROOT / "data"
VAL_CSV = DATA_DIR / "annotations" / "task1" / "val" / "gt.csv"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--metrics-json", type=Path, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.batch_size < 1 or args.num_workers < 0:
        raise ValueError("batch-size must be positive and num-workers must be non-negative.")
    if not args.checkpoint.is_file():
        raise FileNotFoundError(f"Checkpoint does not exist: {args.checkpoint}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_amp = device.type == "cuda"
    validation_dataset = PedestrianAttributeDataset(VAL_CSV, DATA_DIR, transform=build_validation_transform())
    validation_loader = create_loader(
        validation_dataset,
        args.batch_size,
        args.num_workers,
        False,
        device,
        seed=0,
    )

    checkpoint: dict[str, Any] = torch.load(args.checkpoint, map_location=device, weights_only=False)
    if tuple(checkpoint["attribute_names"]) != validation_dataset.attribute_names:
        raise ValueError("Checkpoint attribute order does not match the official validation CSV.")

    model = create_resnet50(pretrained=False).to(device)
    model.load_state_dict(checkpoint["model_state"])
    if model.fc.out_features != 40:
        raise RuntimeError(f"Checkpoint model must have exactly 40 outputs, found {model.fc.out_features}.")

    validation_loss, metrics = evaluate_model(
        model,
        validation_loader,
        nn.BCEWithLogitsLoss(),
        device,
        use_amp,
    )
    print(f"Validation BCEWithLogitsLoss: {validation_loss:.6f}")
    for name, value in metrics.items():
        print(f"{name}: {value:.6f}")

    if args.metrics_json is not None:
        args.metrics_json.parent.mkdir(parents=True, exist_ok=True)
        with args.metrics_json.open("w", encoding="utf-8") as handle:
            json.dump({"val_loss": validation_loss, **metrics}, handle, indent=2)
        print(f"Saved metrics to {args.metrics_json}")


if __name__ == "__main__":
    main()
