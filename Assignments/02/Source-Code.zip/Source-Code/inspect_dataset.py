"""Read-only integrity and class-balance inspection for UPAR Track 1 data."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import numpy as np
import torch

from src.dataset import PedestrianAttributeDataset


REPO_ROOT = Path(__file__).resolve().parent
DATA_DIR = REPO_ROOT / "data"
TRAIN_CSV = DATA_DIR / "annotations" / "task1" / "train" / "gt.csv"
VAL_CSV = DATA_DIR / "annotations" / "task1" / "val" / "gt.csv"


def pil_to_tensor(image):
    """Convert an RGB PIL image to a CHW float32 tensor without torchvision."""
    array = np.array(image, dtype=np.uint8, copy=True)
    return torch.from_numpy(array).permute(2, 0, 1).float().div(255.0)


def find_missing_images(dataset: PedestrianAttributeDataset) -> list[Path]:
    missing: list[Path] = []
    for index in range(len(dataset)):
        image_path = dataset.image_path(index)
        if not image_path.is_file():
            missing.append(image_path)
    return missing


def duplicate_paths(dataset: PedestrianAttributeDataset) -> list[str]:
    counts = Counter(dataset.relative_image_paths)
    return sorted(path for path, count in counts.items() if count > 1)


def print_split_checks(name: str, dataset: PedestrianAttributeDataset) -> None:
    binary_labels = bool(np.isin(dataset.labels, (0.0, 1.0)).all())
    duplicates = duplicate_paths(dataset)
    missing = find_missing_images(dataset)

    print(f"{name}: {len(dataset):,} samples")
    print(f"  labels_are_binary_0_or_1: {binary_labels}")
    print(f"  duplicate_csv_image_paths: {len(duplicates):,}")
    if duplicates:
        print(f"    first_duplicate: {duplicates[0]}")
    print(f"  missing_referenced_images: {len(missing):,}")
    if missing:
        print(f"    first_missing: {missing[0]}")


def print_attribute_summary(
    train_dataset: PedestrianAttributeDataset,
    val_dataset: PedestrianAttributeDataset,
) -> None:
    if train_dataset.attribute_names != val_dataset.attribute_names:
        raise ValueError("Train and validation CSV files use different attribute orders.")

    train_counts = train_dataset.labels.sum(axis=0, dtype=np.int64)
    val_counts = val_dataset.labels.sum(axis=0, dtype=np.int64)
    print("\nAttribute positive counts and percentages")
    print("index  attribute                              train count (%)       val count (%)")
    for index, attribute_name in enumerate(train_dataset.attribute_names):
        train_percent = 100.0 * train_counts[index] / len(train_dataset)
        val_percent = 100.0 * val_counts[index] / len(val_dataset)
        print(
            f"{index + 1:>2}     {attribute_name:<38} "
            f"{train_counts[index]:>6,} ({train_percent:>6.2f}%)   "
            f"{val_counts[index]:>6,} ({val_percent:>6.2f}%)"
        )


def print_samples(dataset: PedestrianAttributeDataset) -> None:
    print("\nThree loaded training samples")
    for index in range(min(3, len(dataset))):
        image, labels = dataset[index]
        print(
            f"  index={index} image_shape={tuple(image.shape)} "
            f"label_shape={tuple(labels.shape)} positive_attributes={int(labels.sum().item())}"
        )


def main() -> None:
    train_dataset = PedestrianAttributeDataset(TRAIN_CSV, DATA_DIR, transform=pil_to_tensor)
    val_dataset = PedestrianAttributeDataset(VAL_CSV, DATA_DIR)

    print_split_checks("train", train_dataset)
    print_split_checks("val", val_dataset)
    print_attribute_summary(train_dataset, val_dataset)
    print_samples(train_dataset)


if __name__ == "__main__":
    main()
