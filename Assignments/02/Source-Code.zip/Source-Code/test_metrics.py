"""Small, manually checkable tests for the UPAR Track 1 metric implementation."""

from __future__ import annotations

import numpy as np

from src.metrics import compute_track1_metrics


def assert_metric_values(metrics: dict[str, float], expected: dict[str, float]) -> None:
    for name, expected_value in expected.items():
        np.testing.assert_allclose(metrics[name], expected_value, rtol=0.0, atol=1e-12)


def test_perfect_predictions() -> None:
    targets = np.array([[1, 0], [0, 1]], dtype=np.float32)
    probabilities = np.array([[0.9, 0.1], [0.1, 0.9]], dtype=np.float32)

    metrics = compute_track1_metrics(probabilities, targets)
    assert_metric_values(metrics, {name: 1.0 for name in metrics})


def test_deliberately_incorrect_predictions() -> None:
    targets = np.array([[1, 0], [1, 0], [0, 1]], dtype=np.float32)
    probabilities = np.array([[0.9, 0.1], [0.1, 0.1], [0.9, 0.9]], dtype=np.float32)

    metrics = compute_track1_metrics(probabilities, targets)
    assert_metric_values(
        metrics,
        {
            "mA": 0.625,
            "Label_F1": 0.75,
            "Instance_Acc": 0.5,
            "Instance_Prec": 0.5,
            "Instance_Rec": 2.0 / 3.0,
            "Instance_F1": 4.0 / 7.0,
            "Challenge_Avg": 2.0 * 0.625 * (4.0 / 7.0) / (0.625 + (4.0 / 7.0)),
        },
    )


def test_zero_denominator_and_strict_threshold() -> None:
    targets = np.array([[1, 0], [0, 0]], dtype=np.float32)
    probabilities = np.full_like(targets, 0.5)

    metrics = compute_track1_metrics(probabilities, targets)
    assert_metric_values(
        metrics,
        {
            "mA": 0.5,
            "Label_F1": 0.0,
            "Instance_Acc": 0.0,
            "Instance_Prec": 0.0,
            "Instance_Rec": 0.0,
            "Instance_F1": 0.0,
            "Challenge_Avg": 0.0,
        },
    )


def main() -> None:
    test_perfect_predictions()
    test_deliberately_incorrect_predictions()
    test_zero_denominator_and_strict_threshold()
    print("All metric tests passed.")


if __name__ == "__main__":
    main()
