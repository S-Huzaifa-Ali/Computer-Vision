# UPAR Challenge 2027 — Track 1 Source Code

This folder contains the source code used for the Computer Vision assignment on **UPAR Challenge 2027 Track 1: Pedestrian Attribute Recognition**.

## Project Summary

The task is to predict 40 binary pedestrian attributes from surveillance-style pedestrian images.

The implemented baseline uses:
- ImageNet-pretrained ResNet-50
- 40-output classification head
- BCEWithLogitsLoss
- AdamW optimizer
- mixed-precision CUDA training
- official UPAR evaluation metrics

Best local validation `Challenge_Avg`: **0.834636**

Official Codabench hidden-test score: **0.7021**

Codabench Submission ID: **1004995**

## Source Code Structure

```text
Source_Code/
├── train.py
├── evaluate.py
├── inspect_dataset.py
├── test_metrics.py
├── README.md
├── src/
│   ├── __init__.py
│   ├── dataset.py
│   ├── experiment.py
│   ├── metrics.py
│   └── model.py
└── submission/
    ├── run.py
    └── metadata.yaml
```

Optional result files may also be included:

```text
Results/
├── training_log.csv
└── validation_metrics.json
```

## Environment Used Locally

- Python 3.12.5
- PyTorch 2.4.1 + CUDA 12.1
- torchvision 0.19.1
- NVIDIA GeForce RTX 4050 Laptop GPU, 6 GB VRAM

The official Codabench environment uses Python 3.11, PyTorch 2.4.1, torchvision, NumPy, and Pillow with no network access.

## Dataset

The official UPAR Challenge 2027 Track 1 data was used.

- Training images: 97,669
- Validation images: 33,407
- Attributes: 40 binary labels

The dataset itself is **not included** in this source-code archive because of its size and licensing restrictions.

## Training

From the repository root, activate the project environment and run:

```powershell
python train.py `
  --epochs 10 `
  --batch-size 32 `
  --num-workers 4 `
  --lr 1e-4 `
  --weight-decay 1e-4 `
  --seed 42
```

Main training configuration:
- ResNet-50 pretrained on ImageNet
- Input size: 256 × 128
- BCEWithLogitsLoss
- AdamW
- learning rate: 1e-4
- weight decay: 1e-4
- batch size: 32
- 10 epochs
- mixed precision enabled

The best checkpoint is selected using validation `Challenge_Avg`.

## Evaluation

To evaluate the best checkpoint:

```powershell
python evaluate.py `
  --checkpoint .\outputs\baseline_resnet50\best_model.pth `
  --metrics-json .\outputs\baseline_resnet50\validation_metrics.json
```

Best validation metrics:

| Metric | Score |
|---|---:|
| mA | 0.807321 |
| Label_F1 | 0.692363 |
| Instance_Acc | 0.774283 |
| Instance_Prec | 0.874596 |
| Instance_Rec | 0.853393 |
| Instance_F1 | 0.863864 |
| Challenge_Avg | 0.834636 |

## Dataset Inspection and Metric Tests

Dataset integrity check:

```powershell
python inspect_dataset.py
```

Metric unit tests:

```powershell
python test_metrics.py
```

The final checks found:
- 0 missing referenced images
- 0 duplicate CSV image paths
- all labels were binary 0/1
- all metric unit tests passed

## Codabench Submission

The exact Codabench submission ZIP is provided separately as:

`submission_track1_baseline.zip`

Its root contains:

```text
run.py
metadata.yaml
model_state.pth
```

The submission:
- runs offline
- loads packaged model weights
- performs batched inference
- returns 40 probabilities per image
- achieved an official hidden-test score of **0.7021**

## Notes

Do not include the following in `Source_Code.zip`:
- `.venv/`
- `data/`
- downloaded dataset ZIP files
- `.torch/`
- `__pycache__/`
- large temporary checkpoints unless specifically requested

The trained Codabench model weights are already included in the separate `submission_track1_baseline.zip`.
